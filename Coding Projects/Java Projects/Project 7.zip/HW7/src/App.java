//super class App

public class App {

    private double lbs;
    private double height;
   
    // constructor to set the lbs and height of animal to passed parameters
    public App(double lbs, double height)
    {
        this.lbs = lbs;
        this.height = height;
    }
   
    // default constructor
    public App()
    {
        lbs = 0 ;
        height = 0;
    }
   
    // mutator
    public void setlbs(double lbs)
    {
        this.lbs = lbs;
    }
   
    public void setHeight(double height)
    {
        this.height = height;
    }
   
    // accessor
    public double getlbs()
    {
        return lbs;
    }
   
    public double getHeight()
    {
        return height;
    }
   
    //toString
    public String toString()
    {
        return("lbs : "+lbs+" Height : "+height);
    }
 }

 
