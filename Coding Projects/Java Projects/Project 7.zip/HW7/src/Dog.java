public class Dog extends App {

    private String name;
    private String breed;


    public Dog() {
        super();
        name = "";
        breed = "";
    }

    public Dog(String name, String breed, double lbs, double height) {
        super(lbs, height); // call Animal class constructor
        this.name = name;
        this.breed = breed;
    }

    // mutators
    public void setName(String name) {
        this.name = name;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }

    // accessors
    public String getName() {
        return name;
    }

    public String getBreed() {
        return breed;
    }

    // toString
    public String toString() {
        return ("Name : " + name + " Breed : " + breed + " " + super.toString());
    }
}