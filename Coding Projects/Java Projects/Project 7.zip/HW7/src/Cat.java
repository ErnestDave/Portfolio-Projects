public class Cat extends App{
   
    private String name;
    private int livesRemaining;
   
    // default constructor
    public Cat()
    {
        super();
        name="";
        livesRemaining = 9;
    }
   
    // constructor to set the name, lbs and height to passed parameters and set livesRemaining to 9
    public Cat(String name, double lbs, double height)
    {
        super(lbs, height);
        this.name = name;
        livesRemaining = 9;
    }
 
    // mutators  
    public void setName(String name)
    {
        this.name = name;
    }
   
    // method to invoke when the cat dies
    public void dead()
    {
        // if number of lives remaining > 0, decrement the number of lives
        if(livesRemaining > 0)
            livesRemaining--;
    }
   
    // accessors
    public String getName()
    {
        return name;
    }
   
    public int numLivesRemaining()
    {
        return livesRemaining;
    }
   
    // toString
    public String toString()
    {
        return("Name : "+name+" Number of lives remaining : "+livesRemaining+" "+super.toString());
    }
   
 }