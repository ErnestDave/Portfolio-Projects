public class Bird extends App{
 
    private double wingSpan;
    private boolean canFly;
   
    // default constructor
    public Bird()
    {
        super();
        wingSpan = 0;
        canFly = false;
    }
   
    // constructor to set the wingSpan, whether the bird can fly or not, lbs and height to passed parameters
    public Bird (double wingSpan, boolean canFly, double lbs, double height)
    {
        super(lbs, height);
        this.wingSpan = wingSpan;
        this.canFly = canFly;
    }
   
    // mutators
    public void setWingSpan(double wingSpan)
    {
        this.wingSpan = wingSpan;
    }
   
    public void setCanFly(boolean canFly)
    {
        this.canFly = canFly;
    }
   
    // accessors
    public double getWingSpan()
    {
        return wingSpan;
    }
   
    public boolean getCanFly()
    {
        return canFly;
    }
   
    //toString
    public String toString()
    {
        return("Wing span : "+wingSpan+" Can Fly : "+canFly+" "+super.toString());
    }
   
 }
 //end of Bird.java