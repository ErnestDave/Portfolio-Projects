public class Main{
 
   
    public static void main(String[] args)
    {
        // create method to display weight, height, wingspan, and ability to fly. 
        Dog dog = new Dog("GS","Rotwiler",48.65,6.32);
        Cat cat = new Cat ("Simba",63, 3.2);
        Bird bird = new Bird (11.75,true,27,3.98);
       
        // diplay the name of the pets
        System.out.println("Dog : "+dog);
        System.out.println("Cat : "+cat);
        System.out.println("Bird : "+bird);
    }
 }