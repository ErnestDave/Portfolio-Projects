import java.util.Scanner;


public class App {
    //create an array 25 rows and unknown columns
    private static int stdnt[][] = new int[25][];
    public static void menu() {
        
        //initialize number of stdnt to 0
        int number = 0;
        Scanner input = new Scanner(System.in); 
        int choose; 
       
        //initialize amount of exams taken by a student
        int maxExams = 0; 
        do {
           
           
            //allow user to choose from menu
            System.out.println("1-Input grades for next student");
            
            System.out.println("2-Display the exam average by student.");
            
            System.out.println("3-Display the exam average by exam");
            
            System.out.println("4-Display the current class average for all exams");
            
            System.out.println("5-Exit");
            
            
            choose = input.nextInt();
            
            
            //allow user to input number of exams
            if (choose == 1) { 
                System.out.println("Please enter how many exams this student has taken?");
                int numbofexams = input.nextInt(); 
                
                //number of exams is made into an array
             stdnt[number] = new int[numbofexams];
                System.out.println("Please enter the each of those exam scores one by one"); //enter scores
                if (maxExams < numbofexams) 
                    maxExams = numbofexams;
               
                for (int i = 0; i < numbofexams; i++) {
                 stdnt[number][i] = input.nextInt();
                }
                number++; 
            } else if (choose == 2) {
                
                
                //calculate and display avereage by student and also student iD
                System.out.println("*** Average by Student Id ***");
                System.out.println("Student Id\tAverage Score");
                for (int i = 0; i < number; i++) {
                    System.out.print((i + 1) + "\t");
                    int sum = 0;
                    //calculate sum
                    for (int j = 0; j < stdnt[i].length; j++) {
                        sum = sum + stdnt[i][j];
                    }

                    //find  and display average 
                    double avg = sum * 1.0 / stdnt[i].length;
                    System.out.printf("%.2f", avg); 
                    System.out.println();
                }
            } else if (choose == 3) 
            
            
            {   //calcaualte and display average by exam number
                System.out.println("*** Average by Exam Number ***");
                System.out.println("Exam Number\tAverage Score");
                for (int i = 0; i < maxExams; i++) {
                    int sum = 0, total = 0;
                    for (int j = 0; j < number; j++) {
                        if  (stdnt[j].length >= i + 1) {
                            total++;
                            sum = sum + stdnt[j][i];
                        }
                    }
                    double avg = sum * 1.0 / total;
                    System.out.print((i + 1) + "\t");
                    System.out.printf("%.2f", avg);
                    System.out.println();
                }
            } else if (choose == 4) 
            
            {  //calcualate average for the whole class
                int sumtotal = 0;
                for (int i = 0; i < number; i++) {
                    int sum = 0;
                    for (int j = 0; j < stdnt[i].length; j++) {
                        sum = sum + stdnt[i][j];
                    }
                    double avg = sum * 1.0 / stdnt[i].length;
                    sumtotal += avg;
                }
                double avgTotal = sumtotal * 1.0 / number;
                System.out.println("Current class Average for all exams - " + avgTotal);
            }

        } while (choose != 5);
    }
    //run main menu
    public static void main(String[] args) {
        menu();
    }
}