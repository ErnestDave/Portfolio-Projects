/*  Created By: Dave Ernest on 06/19/2020
    
    Purpose:    Demonrate ability to write and call methods, pass values to and from methods.           
*/


import java.util.*;
import java.io.*;

class App {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        //Provide menu options to user
        System.out.println("\n\nMenu Options: ");
        System.out.println("-----------------------------------");
        System.out.println("1. Echo first name 20 times");
        System.out.println("2. The age and the doubled age");
        System.out.println("3. Teenager or Not a teenager");
        System.out.println("4. Create a triangle");

        System.out.print("\nEnter your choice: ");
        int choice = sc.nextInt();


        switch (choice) {

            //Option 1 to echo user's name
            case 1:
                System.out.print("\nEnter user's first name: ");
                String fname = sc.next();
                for (int i = 1; i <= 20; i++) {
                    System.out.println(i + ": " + fname);
                }
                break;


            //Option 2 to double user's age
            case 2:
                System.out.print("\nEnter user's age: ");
                int age2 = sc.nextInt();
                System.out.println("\nThe age: " + age2);
                System.out.println("\nThe doubled age: " + (age2 * 2));
                break;


                //Option 3 to verify if user is a teenager or not
            case 3:
                System.out.print("\nEnter user's age: ");
                int age3 = sc.nextInt();
                if (age3 >= 13 && age3 <= 19) {
                    System.out.println("\nSince you are " + age3 + " years old, you are a teenanger.");
                } else {
                    System.out.println("\nSince you are " + age3 + " years old, you are NOT a teenanger.");
                }
                break;


                //Otion 4 To allow user to make triangle text box 
            case 4:
                String output = "";
                System.out.print("\nEnter an integer between 3 and 50: ");
                int num = sc.nextInt();

                for (int i = 1; i <= num; i++) {
                    for (int sp = num; sp >= i; sp--) {
                        System.out.print(" ");
                        output = output + " ";
                    }
                    for (int j = 1; j <= i; j++) {
                        System.out.print("X");
                        System.out.print(" ");
                        output = output + "X";
                    }
                    System.out.print("\n");
                    output = output + "\n";
                }
                try {
                    FileWriter fw = new FileWriter("triangle.txt");
                    fw.write(output);
                    fw.close();
                } catch (Exception e1) {
                    System.out.println(e1);
                }
                break;


                //if user innputs wrong information
            default:
                System.out.println("Invalid menu option!!!");
                break;
        }
        System.out.println("\n");
    }
}