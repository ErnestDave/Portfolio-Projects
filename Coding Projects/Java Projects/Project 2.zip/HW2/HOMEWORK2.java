/* 05.29.2020
 * Homework 2: experimenting primitive data types, variables, print output, scanner input, and arithmetic operators. 
 *-Dave Ernest
 */

import java.util.Scanner;
// include scanner class

public class HOMEWORK2 {

	public static void main(String[] args) {
		
		int a, b, c, sum;
		double avg;
		// include variables for a, b, c, to be included in sum and average
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter 2 numbers please:");
		
		a = scan.nextInt();
		b = scan.nextInt();
		
		System.out.println("Thank you, now please enter a 3rd number:");
		
		c = scan.nextInt();
		
		
		scan.close();
		// end of variable inputs
		
		sum = a + b + c;
		avg = sum/3;
		// take the average and sum of the three numbers
		System.out.println("You have entered these 3 numbers: "+a+", "+b+", " +c);
		
		System.out.println("The sum of your 3 numbers is:" +sum);
		
		System.out.println("The average of your 3 numbers is :" +avg);
		
		// Display the three numbers, the sum, and the average
		

	}

}
