/*  Created By: Dave Ernest on 06/25/2020
    
    Purpose:    Demonrate ability to  to use a one-dimensional array, sort and search arrays, & use methdods.

*/

import java.util.Arrays;
import java.util.Scanner;

public class App {

   public static void main(String[] args) {
       

       //initialize the array of 1-100
       int[] rand= new int[100];
       for(int i=0;i<100;i++)
           rand[i]=(int)(Math.random()*100)+1;

    //main method calls all of the methods at play
       printArray(rand);
       sortArray(rand);
       printArray(rand);
       System.out.println("Enter a number between 1 and 100");
       Scanner sc=new Scanner(System.in);
       int n=sc.nextInt();
       search(rand,n);
       System.out.println("Frequency of each number in array");
       countFreq(rand, rand.length);
       average(rand);
       greatest(rand);
       least(rand);
   }

//method to find and display the least possible value in the array
   private static void least(int[] rand) {
       int min=100;
       for(int i:rand) {
           if(i < min )  
               min=i;
       }
       System.out.println("least number in array is "+min);
   }

//method to find and display the greatest possible value in the array
   private static void greatest(int[] rand) {
       int max=0;
       for(int i:rand) {
           if(i > max)
               max=i;
       }
       System.out.println("greatest number in array is "+max);
   }

//method to find and display the avearage value of all numbers in the array
   private static void average(int[] rand) {
       
       int total=0;
       for(int i : rand) {
           total=total+i;
       }
       System.out.println("Average of numbers in array "+total/rand.length);
   }

//method to find and display the frequency of all number in the array
   private static void countFreq(int[] arr, int n) {
       boolean visited[] = new boolean[n];
  
   Arrays.fill(visited, false);
  
   for (int i = 0; i < n; i++) {
  
   // Skip number if found already
   if (visited[i] == true)
        continue;
  
   // Count frequency
   int count = 1;
   for (int j = i + 1; j < n; j++) {
   if (arr[i] == arr[j]) {
   visited[j] = true;
   count++;
   }
   }
   System.out.println(arr[i] + " " + count);
   }
   }

//method to find and display the number that the user inputted, if located in array
   private static void search(int[] rand, int n) {
       // TODO Auto-generated method stub
       for(int i:rand) {
           if(i == n) {
               System.out.println("Found");
               return;
           }
              
       }
       System.out.println("Not Found");
   }

//method to sort the array in increasing order
   private static void sortArray(int[] d) {
    Arrays.sort(d);
   }

   
//method to diplay the sorted array
   private static void printArray(int[] rand) {

       for(int i : rand) {
           System.out.print(i+" ");
       }
       System.out.println();
   }

}